/* scrpits/ui/shop/ShopWindow.ts
 * 商店窗口（从对话打开）
 * - 左：NPC 商品（用 InventoryPanel 渲染）
 * - 右：玩家背包（用 InventoryPanel 渲染）
 * - 点击左侧格子 = 购买 1 个；点击右侧格子 = 出售 1 个
 * - 金币读取 GameRoot 上的 CurrencyManager（可选；没有则不扣不加）
 */
import {
  _decorator, Component, Node, UITransform, Widget, Graphics, Color, Label, Vec3, find
} from 'cc';
const { ccclass } = _decorator;

@ccclass('ShopWindow')
export class ShopWindow extends Component {
  private static _inst: ShopWindow | null = null;

  /** 单例：创建在 Canvas 下 */
  public static instance(): ShopWindow {
    if (this._inst && this._inst.node.isValid) return this._inst;
    const canvas = find('Canvas');
    const n = new Node('ShopWindow');
    canvas?.addChild(n);
    this._inst = n.addComponent(ShopWindow);
    this._inst._build();
    return this._inst;
  }

  /** 对外入口：基于 NPC 打开 */
  public static openForNPC(npcNode: Node, itemDBNode?: Node | null, playerNode?: Node | null) {
    const inst = this.instance();
    inst._open(npcNode, itemDBNode || find('GameRoot'), playerNode || find('play'));
  }

  // 外部引用
  private _itemDBNode: Node | null = null;  // GameRoot（有 ItemDatabase）
  private _playerNode: Node | null = null;  // 玩家（有 PickupToInventory）
  private _npcNode: Node | null = null;     // 正在对话的 NPC（有 NPCShop）

  // UI
  private _bg!: Node;
  private _left!: Node;     // NpcGoods 的 InventoryPanel
  private _right!: Node;    // Player 的 InventoryPanel
  private _coinLb!: Label;

  // 桥：把 NPC 商品放进一个“临时背包”以复用 InventoryPanel
  private _goodsBridgeNode!: Node;
  private _goodsBridge: any = null;
  private _playerBridge: any = null;
  private _currency: any = null;

  private _cellBound = false;

  /* ---------- 构建 UI 基础壳 ---------- */
  private _build() {
    this._bg = new Node('Bg'); this.node.addChild(this._bg);
    const ui = this._bg.addComponent(UITransform); ui.setContentSize(1280, 720);
    const wg = this._bg.addComponent(Widget);
    wg.isAlignLeft = wg.isAlignRight = wg.isAlignTop = wg.isAlignBottom = true;
    wg.left = wg.right = wg.top = wg.bottom = 0;

    // 半透明遮罩
    const mask = new Node('Mask'); this._bg.addChild(mask);
    mask.addComponent(UITransform).setContentSize(1280, 720);
    const g = mask.addComponent(Graphics); g.fillColor = new Color(0,0,0,140); g.rect(-640,-360,1280,720); g.fill();

    // 标题 & 金币
    const title = new Node('Title'); this._bg.addChild(title);
    title.addComponent(UITransform).setContentSize(400, 40);
    title.setPosition(new Vec3(0, 300));
    const tLb = title.addComponent(Label); tLb.string = '商店'; tLb.fontSize = 26; tLb.lineHeight = 30;

    const coin = new Node('Coins'); this._bg.addChild(coin);
    this._coinLb = coin.addComponent(Label); this._coinLb.string = '金币：0'; this._coinLb.fontSize = 22; this._coinLb.lineHeight = 26;
    coin.setPosition(new Vec3(460, 300));

    // 左右容器
    this._left = new Node('NpcGoodsPanel'); this._bg.addChild(this._left);
    this._left.addComponent(UITransform).setContentSize(520, 520);
    const lw = this._left.addComponent(Widget); lw.isAlignLeft = true; lw.left = 40; lw.isAlignTop = true; lw.top = 70;

    this._right = new Node('PlayerInvPanel'); this._bg.addChild(this._right);
    this._right.addComponent(UITransform).setContentSize(520, 520);
    const rw = this._right.addComponent(Widget); rw.isAlignRight = true; rw.right = 40; rw.isAlignTop = true; rw.top = 70;

    // 关闭
    const close = new Node('Close'); this._bg.addChild(close);
    close.addComponent(UITransform).setContentSize(120,40);
    const cLb = close.addComponent(Label); cLb.string = '关闭'; cLb.fontSize = 24; cLb.lineHeight = 28;
    close.setPosition(new Vec3(0, -300));
    close.on(Node.EventType.TOUCH_END, ()=> this.node.active = false);

    this.node.active = false;
  }

  /** 确保左右都挂上 InventoryPanel，并绑定点击（与现有背包一致） */
  private _ensurePanels() {
    const ensurePanel = (host: Node) => {
      let p = host.getComponent('InventoryPanel') as any;
      if (!p) { (host as any).addComponent('InventoryPanel'); p = host.getComponent('InventoryPanel'); }
      // 绑定数据源
      p.itemDBNode = this._itemDBNode;
      return p;
    };
    const leftP = ensurePanel(this._left);
    const rightP = ensurePanel(this._right);
    leftP.invBridgeNode = this._goodsBridgeNode;
    rightP.invBridgeNode = this._playerNode;

    leftP.refresh?.(); rightP.refresh?.();

    // 给每个 Cell 绑定点击
    this._bindCellClicks(leftP, true);
    this._bindCellClicks(rightP, false);
  }

  private _bindCellClicks(panel: any, isLeft: boolean) {
    if (!panel || !panel.gridRoot) return;
    if (this._cellBound) {
      for (const n of panel.gridRoot.children) n.off(Node.EventType.TOUCH_END);
    }
    for (const n of panel.gridRoot.children) {
      if (!n.name.startsWith('Cell_')) continue;
      n.on(Node.EventType.TOUCH_END, () => {
        const idx = parseInt(n.name.slice(5)) || 0;
        isLeft ? this._buy(idx) : this._sell(idx);
      });
    }
    this._cellBound = true;
  }

  /* ---------- 对外：打开 ---------- */
  private _open(npcNode: Node | null, itemDBNode: Node | null, playerNode: Node | null) {
    if (!npcNode || !itemDBNode || !playerNode) { console.warn('[ShopWindow] 缺少引用'); return; }
    this._npcNode = npcNode; this._itemDBNode = itemDBNode; this._playerNode = playerNode;

    this._currency = find('GameRoot')?.getComponent('CurrencyManager'); // 可选
    this._playerBridge = this._playerNode.getComponent('PickupToInventory');

    // 构建 NPC 商品“临时背包”
    if (!this._goodsBridgeNode || !this._goodsBridgeNode.isValid) {
      this._goodsBridgeNode = new Node('NpcGoodsBridge');
      this.node.addChild(this._goodsBridgeNode);
      (this._goodsBridgeNode as any).addComponent('PickupToInventory');
    }
    this._goodsBridge = this._goodsBridgeNode.getComponent('PickupToInventory');
    this._goodsBridge.itemDB = this._itemDBNode.getComponent('ItemDatabase');
    if (!this._goodsBridge.inventory) this._goodsBridge.onLoad?.();

    const inv = this._goodsBridge.inventory;
    if (!inv) { console.warn('[ShopWindow] goods bridge 无 inventory'); return; }
    for (let i=0;i<inv.slots.length;i++) inv.slots[i] = null;

    const cfg = this._npcNode.getComponent('NPCShop') as any;
    if (!cfg) { console.warn('[ShopWindow] 该 NPC 没有 NPCShop 配置'); return; }

    let fill = 0;
    for (const g of cfg.goods as any[]) {
      if (!g || !g.id) continue;
      const count = g.stock < 0 ? 99 : Math.max(0, g.stock); // -1 用 99 表示“多”
      if (count <= 0) continue;
      if (fill < inv.slots.length) inv.slots[fill++] = { id: g.id, count };
    }

    this._ensurePanels();
    this._refreshCoins();
    this.node.active = true;
  }

  private _refreshCoins() {
    if (!this._coinLb) return;
    const c = this._currency?.coins ?? 0;
    this._coinLb.string = `金币：${c|0}`;
  }

  /* ---------- 购买 / 出售 ---------- */
  private _buy(idx: number) {
    const cfg = this._npcNode?.getComponent('NPCShop') as any;
    if (!cfg || !this._goodsBridge || !this._playerBridge) return;

    const goodsInv = this._goodsBridge.inventory;
    const s = goodsInv?.slots[idx]; if (!s) return;

    const id = s.id;
    const g = (cfg.goods as any[]).find(x=>x.id===id);
    const price = g?.buyPrice ?? 0;
    if (!this._trySpend(price)) return;

    // 玩家 +1
    this._playerBridge.push(id, 1);

    // 库存减少（无限不减）
    if ((g?.stock ?? -1) >= 0) {
      s.count -= 1;
      g.stock -= 1;
      if (s.count <= 0) goodsInv.slots[idx] = null;
    }
    this._refreshAll();
  }

  private _sell(idx: number) {
    const db = this._itemDBNode?.getComponent('ItemDatabase') as any;
    const pb = this._playerBridge; if (!db || !pb) return;
    const inv = pb.inventory; const s = inv?.slots[idx]; if (!s) return;

    const data = db.get?.(s.id);
    const price = data?.sellPrice ?? 0;
    const canSell = (data?.canSell ?? (price>0)) && price>0;
    if (!canSell) { console.log('[ShopWindow] 该物品不可出售'); return; }

    s.count -= 1;
    if (s.count <= 0) inv.slots[idx] = null;

    this._addCoins(price);
    this._refreshAll();
  }

  private _trySpend(n: number): boolean {
    const cm = this._currency;
    if (!cm) return true;
    const ok = cm.trySpend ? cm.trySpend(n) : (cm.coins >= n);
    if (!ok) console.log('[ShopWindow] 金币不足');
    return ok;
    }

  private _addCoins(n: number) {
    const cm = this._currency; if (!cm) return;
    cm.addCoins ? cm.addCoins(n) : (cm.coins = (cm.coins|0) + (n|0));
    this._refreshCoins();
  }

  private _refreshAll() {
    (this._left.getComponent('InventoryPanel') as any)?.refresh?.();
    (this._right.getComponent('InventoryPanel') as any)?.refresh?.();
    this._refreshCoins();
  }
}
