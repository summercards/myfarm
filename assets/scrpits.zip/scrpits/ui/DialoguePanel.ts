/*  DialoguePanel.ts
 *  ���ܣ���򵥵ĶԻ���壨����=NPC��������=�����ʾ����ť=��һ��/�رգ�
 *  ʹ�ã����� Canvas �·�һ���Ի����ڵ㣬�ұ��ű��������á�
 */
import { _decorator, Component, Node, Label, Button, find } from 'cc';

import { ShopWindow } from './shop/ShopWindow';
import { ShopContext } from '../npc/ShopContext';

const { ccclass, property } = _decorator;

type OpenArgs = {
    speaker: string;
    lines: string[];
    onClose?: () => void;
};

@ccclass('DialoguePanel')
export class DialoguePanel extends Component {
    /** �������ң�Canvas �½ڵ���Ĭ�� "DialoguePanel"�� */
    public static instance(): DialoguePanel | null {
        const n = find('Canvas/DialoguePanel');
        return n?.getComponent(DialoguePanel) ?? null;
    }

    @property(Node) panelRoot: Node | null = null;
    @property(Label) speakerLabel: Label | null = null;
    @property(Label) contentLabel: Label | null = null;
    @property(Button) nextBtn: Button | null = null;
    @property(Button) shopBtn: Button | null = null;   // ← Inspector 里把“商店”按钮拖进来

    private _lines: string[] = [];
    private _idx = 0;
    private _onClose: (() => void) | null = null;

    onLoad() {
        this._setVisible(false);
        if (this.nextBtn) {
            this.nextBtn.node.on(Button.EventType.CLICK, this.onClickNext, this);
        }
        if (this.shopBtn) {
  this.shopBtn.node.on(Button.EventType.CLICK, this.onClickShop, this);
}
    }

    onDestroy() {
        if (this.nextBtn) {
            this.nextBtn.node.off(Button.EventType.CLICK, this.onClickNext, this);
        }
        if (this.shopBtn) {
  this.shopBtn.node.off(Button.EventType.CLICK, this.onClickShop, this);
}

    }

    /** �򿪶Ի� */
    public open(args: OpenArgs) {
        this._lines = args.lines ?? [];
        this._idx = 0;
        this._onClose = args.onClose ?? null;

        if (this.speakerLabel) this.speakerLabel.string = args.speaker ?? 'NPC';
        this._setVisible(true);
        this._refresh();
    }

    public close() {
        this._setVisible(false);
        if (this._onClose) {
            const cb = this._onClose;
            this._onClose = null;
            cb();
        }
    }

    private onClickShop() {
  const npc = ShopContext.currentNPC;
  if (!npc) { console.warn('[DialoguePanel] 没有当前 NPC 上下文'); return; }
  // GameRoot / play 如果 Inspector 里不固定引用，就让 ShopWindow 自行 find
  ShopWindow.openForNPC(npc);
}

    public onClickNext() {
        if (this._idx < this._lines.length - 1) {
            this._idx++;
            this._refresh();
        } else {
            this.close();
        }
    }

    private _refresh() {
        if (this.contentLabel) {
            this.contentLabel.string = this._lines[this._idx] ?? '';
        }
        // ��ť�İ��ɸ����Ƿ����һ�����л�����ѡ��
    }

    private _setVisible(v: boolean) {
        if (this.panelRoot) this.panelRoot.active = v;
        else this.node.active = v;
    }
}
