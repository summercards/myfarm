import {
    _decorator,
    Component,
    Node,
    UITransform,
    Widget,
    Graphics,
    Color,
    Layers,
    Label,
    Sprite,
    SpriteAtlas,
} from 'cc';
const { ccclass, property } = _decorator;

type Snapshot = Record<string, number>; // id -> count

@ccclass('InventoryPanelView')
export class InventoryPanelView extends Component {
    @property rows = 4;
    @property cols = 5;
    @property cellSize = 84;
    @property gap = 10;

    @property(Color) panelBgColor: Color = new Color(0, 0, 0, 120);
    @property(Color) cellBgColor: Color = new Color(40, 40, 40, 255);
    @property(Color) textColor: Color = new Color(230, 230, 230, 255);

    /** 可选：背包桥接节点（例如挂了 PickupToInventory 的那个节点） */
    @property(Node) invBridgeNode: Node | null = null;

    /** 可选：物品数据库（例如 GameRoot 上的 ItemDatabase） */
    @property(Node) itemDBNode: Node | null = null;

    /** 可选：图标图集（帧名与 ItemData.icon 对应，如 'atom'） */
    @property(SpriteAtlas) iconAtlas: SpriteAtlas | null = null;

    /** 刷新间隔（秒），有桥接时生效 */
    @property refreshInterval = 0.2;

    private gridRoot!: Node;
    private cells: { root: Node; icon: Sprite; count: Label }[] = [];
    private id2IconName: Record<string, string> = {};
    private timerId: number | null = null;

    onLoad() {
        this.node.layer = Layers.Enum.UI_2D;

        // -------- 布局：左上角固定 ----------
        const pad = 16;
        const w = this.cols * this.cellSize + (this.cols - 1) * this.gap + pad * 2;
        const h = this.rows * this.cellSize + (this.rows - 1) * this.gap + pad * 2;

        const ui = this.node.getComponent(UITransform) ?? this.node.addComponent(UITransform);
        ui.setContentSize(w, h);

        const widget = this.node.getComponent(Widget) ?? this.node.addComponent(Widget);
        widget.isAlignTop = true;
        widget.isAlignLeft = true;
        widget.top = 30;
        widget.left = 30;
        widget.alignMode = Widget.AlignMode.ON_WINDOW_RESIZE;

        // 背景
        const bg = new Node('PanelBG');
        bg.layer = Layers.Enum.UI_2D;
        const bgUI = bg.addComponent(UITransform);
        bgUI.setAnchorPoint(0, 1);
        bgUI.setContentSize(w, h);
        const g = bg.addComponent(Graphics);
        g.fillColor = this.panelBgColor;
        g.roundRect(0, 0, w, h, 12);
        g.fill();
        bg.setPosition(-w / 2, h / 2);
        this.node.addChild(bg);

        // 网格根
        this.gridRoot = new Node('Grid');
        this.gridRoot.layer = Layers.Enum.UI_2D;
        const gridUI = this.gridRoot.addComponent(UITransform);
        gridUI.setAnchorPoint(0, 1);
        gridUI.setContentSize(w - pad * 2, h - pad * 2);
        this.gridRoot.setPosition(-w / 2 + pad, h / 2 - pad);
        this.node.addChild(this.gridRoot);

        // 生成格子（每格：底框 + 图标 + 数量）
        for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.cols; c++) {
                const cell = new Node(`Cell_${r}_${c}`);
                cell.layer = Layers.Enum.UI_2D;
                const cui = cell.addComponent(UITransform);
                cui.setAnchorPoint(0.5, 0.5);
                cui.setContentSize(this.cellSize, this.cellSize);

                const cg = cell.addComponent(Graphics);
                cg.fillColor = this.cellBgColor;
                const half = this.cellSize / 2;
                cg.roundRect(-half, -half, this.cellSize, this.cellSize, 8);
                cg.fill();

                // 图标
                const iconNode = new Node('Icon');
                iconNode.layer = Layers.Enum.UI_2D;
                const iui = iconNode.addComponent(UITransform);
                iui.setAnchorPoint(0.5, 0.5);
                iui.setContentSize(this.cellSize - 14, this.cellSize - 14);
                const icon = iconNode.addComponent(Sprite);
                iconNode.setPosition(0, 2);
                cell.addChild(iconNode);

                // 数量
                const cntNode = new Node('Count');
                cntNode.layer = Layers.Enum.UI_2D;
                const lUI = cntNode.addComponent(UITransform);
                lUI.setAnchorPoint(1, 0); // 右下角
                const cnt = cntNode.addComponent(Label);
                cnt.string = '';
                cnt.fontSize = 20;
                cnt.lineHeight = 22;
                cnt.color = new Color(255, 255, 255, 255);
                cntNode.setPosition(half - 6, -half + 4);
                cell.addChild(cntNode);

                const x = c * (this.cellSize + this.gap) + half;
                const y = -(r * (this.cellSize + this.gap) + half);
                cell.setPosition(x, y);
                this.gridRoot.addChild(cell);

                this.cells.push({ root: cell, icon, count: cnt });
            }
        }

        // 可选：标题
        const title = new Node('Title');
        title.layer = Layers.Enum.UI_2D;
        title.addComponent(UITransform);
        const lab = title.addComponent(Label);
        lab.string = '背包';
        lab.fontSize = 18;
        lab.lineHeight = 22;
        lab.color = this.textColor;
        title.setPosition(-w / 2 + 4, h / 2 + 18);
        this.node.addChild(title);

        // 解析 DB（id -> icon 名）
        this.initDBMap();
    }

    start() {
        if (this.invBridgeNode) {
            // 定时刷新（轮询方式，先简单稳定）
            this.schedule(this.refreshFromBridge, this.refreshInterval);
        }
    }

    onDisable() {
        if (this.timerId != null) {
            this.unschedule(this.refreshFromBridge);
            this.timerId = null;
        }
    }

    /** 尝试读取 ItemDatabase，建立 id->iconName 的映射 */
    private initDBMap() {
        this.id2IconName = {};
        if (!this.itemDBNode) return;

        // 兼容你的项目结构：GameRoot 上挂 ItemDatabase，里面有 allItems（预设里看到的）
        const db: any = this.itemDBNode.getComponent('ItemDatabase');
        const list = db?.allItems ?? db?.items ?? null;
        if (list && Array.isArray(list)) {
            for (const entry of list) {
                // 可能是 Node 或 组件
                const node = entry instanceof Node ? entry : null;
                const itemData: any = node ? node.getComponent('ItemData') : entry;
                const id = itemData?.id ?? itemData?.itemId ?? itemData?.ID;
                const icon = itemData?.icon ?? itemData?.Icon;
                if (id && icon) this.id2IconName[id] = String(icon);
            }
        }
    }

    /** 从桥接组件拉取快照并刷新 UI */
    private refreshFromBridge = () => {
        const data = this.getSnapshot();
        this.renderSnapshot(data);
    };

    /** 渲染：把 id/count 映射到格子（前 rows*cols 个） */
    private renderSnapshot(snap: Snapshot) {
        // 变成稳定数组（按 id 排序）
        const pairs = Object.entries(snap)
            .filter(([_, n]) => n > 0)
            .sort((a, b) => a[0].localeCompare(b[0]));

        const max = this.cells.length;
        for (let i = 0; i < max; i++) {
            const cell = this.cells[i];
            const item = pairs[i];

            if (!item) {
                cell.icon.spriteFrame = null!;
                cell.count.string = '';
                continue;
            }

            const [id, count] = item;
            // 图标
            const iconName = this.id2IconName[id] ?? id; // 找不到就尝试用 id 当帧名
            if (this.iconAtlas) {
                const frame = this.iconAtlas.getSpriteFrame(iconName);
                cell.icon.spriteFrame = frame ?? null!;
            } else {
                cell.icon.spriteFrame = null!;
            }
            // 数量
            cell.count.string = count > 1 ? String(count) : '';
        }
    }

    /** 兼容多种桥接形态，尽量拿到 {id:count} */
    private getSnapshot(): Snapshot {
        if (!this.invBridgeNode) return {};
        // 依次尝试这些组件/字段/方法名（和你之前的命名尽量兼容）
        const candidates = [
            'PickupToInventory',
            'InventoryBridge',
            'InventoryStore',
            'BagStore',
        ];

        let comp: any = null;
        for (const name of candidates) {
            comp = this.invBridgeNode.getComponent(name);
            if (comp) break;
        }
        comp = comp ?? this.invBridgeNode.getComponent('PickupToInventory'); // 再兜底一次

        if (!comp) return {};

        let raw: any =
            comp.getSnapshot?.() ??
            comp.snapshot?.() ??
            comp.bag ??
            comp.items ??
            null;

        // 归一化
        const out: Snapshot = {};
        if (!raw) return out;

        if (Array.isArray(raw)) {
            // [{id,count}]
            for (const it of raw) {
                if (it?.id && it?.count != null) out[String(it.id)] = Number(it.count);
            }
        } else if (raw instanceof Map) {
            for (const [k, v] of raw) out[String(k)] = Number(v);
        } else if (typeof raw === 'object') {
            for (const k of Object.keys(raw)) out[String(k)] = Number(raw[k]);
        }
        return out;
    }
}
