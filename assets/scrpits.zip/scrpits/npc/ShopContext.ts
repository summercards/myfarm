/* scrpits/npc/ShopContext.ts
 * 记录“当前正在对话的 NPC”节点，供对话里的【商店】按钮使用
 */
import { _decorator, Component, Node } from 'cc';
const { ccclass } = _decorator;

@ccclass('ShopContext')
export class ShopContext extends Component {
  /** 当前进入对话的 NPC（由 NPCInteract.startDialogue 设置/清空） */
  public static currentNPC: Node | null = null;
}
