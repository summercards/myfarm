/* scrpits/npc/NPCShop.ts
 * NPC 的商店配置（仅配置，不处理触发器；对话按钮会读取这里的清单）
 */
import { _decorator, Component, CCString } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ShopGoodDef')
export class ShopGoodDef {
  @property({ type: CCString, tooltip: '物品 id（与 ItemDatabase 一致）' })
  id: string = '';
  @property({ tooltip: '购买单价（玩家从 NPC 购买）' })
  buyPrice: number = 10;
  @property({ tooltip: '库存（-1 = 无限）' })
  stock: number = -1;
}

@ccclass('NPCShop')
export class NPCShop extends Component {
  @property({ type: [ShopGoodDef], tooltip: '该 NPC 的在售清单' })
  goods: ShopGoodDef[] = [];
}
