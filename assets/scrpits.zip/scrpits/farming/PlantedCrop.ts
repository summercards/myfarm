/*  Assets/scripts/farming/PlantedCrop.ts
 *  - �������� ItemData.plant �����ֽ׶������
 *  - ��δ���� plant/stages�������Ϊ��������ģ�� + �𲽷Ŵ󡱵ļ򵥰�
 */
import {
    _decorator, Component, Node, Prefab, instantiate, Vec3
} from 'cc';
import { ItemPickup } from '../ItemPickup';
import { PlantingDef, PlantStageDef } from '../items/data/PlantingDefs';
const { ccclass, property } = _decorator;

@ccclass('PlantedCrop')
export class PlantedCrop extends Component {
    @property({ tooltip: '���µ���Ʒ id������ apple��' })
    itemId: string = '';

    @property({ type: Node, tooltip: 'GameRoot���� ItemDatabase��' })
    itemDBNode: Node | null = null;

    private _def: PlantingDef | null = null;
    private _stageIdx = 0;
    private _stageTimer = 0;
    private _model: Node | null = null;
    private _fallbackDur = [3, 5, 7]; // ������ʱ��Ĭ�����׶�ʱ��
    private _fallbackScale = [0.4, 0.7, 1.0];

    onLoad() {
        if (!this.itemDBNode) {
            console.warn('[PlantedCrop] itemDBNode is null');
        }
        if (!this.itemId) {
            console.warn('[PlantedCrop] itemId is empty');
        }

        this._def = this._getPlantDef(this.itemId);
        if (this._def && this._def.stages.length > 0) {
            console.log('[PlantedCrop] use staged growth for', this.itemId, 'stages=', this._def.stages.length);
            this._applyStage(0);
        } else {
            console.log('[PlantedCrop] fallback worldModel for', this.itemId);
            const prefab = this._getWorldModelPrefab(this.itemId);
            if (prefab) {
                this._model = instantiate(prefab);
                this.node.addChild(this._model);
                this._model.setScale(this._fallbackScale[0], this._fallbackScale[0], this._fallbackScale[0]);
            } else {
                console.warn('[PlantedCrop] no prefab for', this.itemId, '(no stage prefab & no worldModel)');
            }
        }
    }


    update(dt: number) {
        this._stageTimer += dt;

        if (this._def && this._def.stages.length > 0) {
            const cur = this._def.stages[this._stageIdx];
            const dur = Math.max(0.01, cur.duration);
            if (this._stageTimer >= dur) {
                this._stageTimer = 0;
                this._stageIdx++;
                if (this._stageIdx >= this._def.stages.length) {
                    this._spawnYield(this._def);
                    this.node.destroy();
                    return;
                }
                this._applyStage(this._stageIdx);
            }
        } else {
            // �������̣����׶�����
            const end = this._fallbackDur[this._stageIdx] ?? 3;
            if (this._stageTimer >= end) {
                this._stageTimer = 0;
                this._stageIdx++;
                if (this._stageIdx >= this._fallbackScale.length) {
                    this._spawnYield(null);
                    this.node.destroy();
                    return;
                }
                if (this._model) {
                    const s = this._fallbackScale[this._stageIdx];
                    this._model.setScale(s, s, s);
                }
            }
        }
    }

    /* -------- �ڲ����׶Ρ����������ݶ�ȡ -------- */

    private _applyStage(i: number) {
        // �����һ�׶�ģ��
        if (this._model && this._model.isValid) {
            this._model.removeFromParent();
            this._model.destroy();
        }

        const stage: PlantStageDef | null = this._def?.stages[i] ?? null;
        let prefab: Prefab | null = null;
        if (stage && stage.prefab) prefab = stage.prefab;
        else prefab = this._getWorldModelPrefab(this.itemId);

        if (prefab) {
            const node = instantiate(prefab);
            this.node.addChild(node);
            const s = stage ? (stage.scale || 1) : 1;
            node.setScale(s, s, s);
            node.setPosition(0, stage ? (stage.offsetY || 0) : 0, 0);
            node.setRotationFromEuler(0, 0, 0);
            this._model = node;
        } else {
            this._model = null;
            console.warn('[PlantedCrop] stage', i, 'has no prefab and no worldModel, id=', this.itemId);
        }

    }

    private _spawnYield(def: PlantingDef | null) {
        const yieldId = (def && def.yieldItemId) ? def.yieldItemId : this.itemId;
        const count = def ? Math.max(1, def.yieldCount) : 1;
        const up = def ? def.dropHeight : 0.1;

        const prefab = this._getWorldModelPrefab(yieldId);
        if (!prefab) return;

        const base = new Vec3();
        this.node.getWorldPosition(base);
        for (let i = 0; i < count; i++) {
            const n = instantiate(prefab);
            const p = n.getComponent(ItemPickup) || n.addComponent(ItemPickup);
            p.itemId = yieldId;
            p.picked = false;

            this.node.parent?.addChild(n);
            const pos = base.clone();
            pos.y += up + i * 0.02;
            n.setWorldPosition(pos);
            n.setRotationFromEuler(0, 0, 0);
        }
    }

    private _getPlantDef(id: string): PlantingDef | null {
        const db: any = this.itemDBNode?.getComponent('ItemDatabase');
        if (!db) return null;

        let data: any = null;
        try {
            if (typeof db.get === 'function') data = db.get(id);
        } catch { }

        if (!data) {
            if (db.byId && db.byId[id]) data = db.byId[id];
            else if (db.map && db.map[id]) data = db.map[id];
        }
        if (data && data.plant && data.plant.plantable) return data.plant as PlantingDef;
        return null;
    }

    private _getWorldModelPrefab(id: string): Prefab | null {
        const db: any = this.itemDBNode?.getComponent('ItemDatabase');
        if (!db) return null;
        try {
            if (typeof db.get === 'function') {
                const d = db.get(id);
                return d && d.worldModel ? (d.worldModel as Prefab) : null;
            }
        } catch { }
        if (db.byId && db.byId[id] && db.byId[id].worldModel) return db.byId[id].worldModel as Prefab;
        if (db.map && db.map[id] && db.map[id].worldModel) return db.map[id].worldModel as Prefab;
        return null;
    }
}
