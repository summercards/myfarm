import { _decorator, Component, SpriteFrame, Prefab } from 'cc';
import { ItemCategory } from './ItemCategory';
import { ItemActionType } from './ItemActionType';
const { ccclass, property } = _decorator;

/**
 * 物品的“静态模板数据”。做法：在层级里创建空节点，挂本组件，设置字段后保存为 Prefab 资产。
 * 之后将这些 Prefab 拖入 ItemDatabase 的 allItems 列表。
 */
@ccclass('ItemData')
export class ItemData extends Component {
  @property
  id: string = 'apple';           // 唯一ID（用于查表与保存）

  @property
  displayName: string = '苹果';   // 展示名称

  @property({ type: SpriteFrame })
  icon: SpriteFrame | null = null; // UI 图标

  @property({ type: Prefab })
  worldModel: Prefab | null = null; // 世界中的3D模型 Prefab（掉落/放置用）

  @property({ type: ItemCategory })
  category: ItemCategory = ItemCategory.Resource;

  @property
  maxStack: number = 99;          // 最大堆叠（至少为1）

  @property
  description: string = '';       // 说明文字

  @property({ type: ItemActionType })
  actionType: ItemActionType = ItemActionType.None;

  // ——动作相关参数（按需才用）——
  @property
  eatRecoverStamina: number = 0;  // Eat: 恢复体力

  @property
  placePrefabYawSnap: number = 90; // Place: 旋转吸附步进（度）

  @property
  toolPower: number = 0;          // ToolUse: 工具威力（砍伐/收割）
}
